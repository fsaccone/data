#!/usr/bin/env python3
"""
Lints the files with clang-format.
Open `README.md` for more informations.
"""

import argparse
import glob
import os
import re
import shutil
import subprocess
import sys
from typing import List, Tuple

FORMATS_TO_LINT = ['cc', 'h']

def lint_files(
    src_path: str,
    executable: str,
    files: List[str],
    quiet: bool,
    fix: bool,
) -> Tuple[List[str], str, int]:
    """
    Returns a list of files that don't match the filename convention, the name of
    the convention and the return code.
    """
    if not shutil.which(executable):
        raise Exception(f'Unable to find the `{executable}` executable.')

    filename_problem_paths: List[str] = []
    code = 1

    for file in files:
        filename_matches = re.match(
            # kebab-case
            f'^([a-z]+(-[a-z])?)+(\.({"|".join(FORMATS_TO_LINT)}))$',
            os.path.basename(file),
        )

        if not filename_matches:
            filename_problem_paths.append(file)

        command = [executable, '-i', file, '--style=file'] + (
            ['--dry-run'] if not fix else []
        )

        try:
            if quiet:
                code = subprocess.run(
                    command,
                    cwd=src_path,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    universal_newlines=True,
                ).returncode
            else:
                code = subprocess.run(
                    command,
                    cwd=src_path,
                    universal_newlines=True,
                ).returncode

        except OSError as error:
            raise Exception(f'An unexpected error occurred while running `{executable}`')
        except:
            code = 1

        if code != 0:
            break

    return (filename_problem_paths, 'kebab-case', code)

def relative_to_abs_path(path: str) -> str:
    return os.path.abspath(path)

def get_ignores(src_path: str) -> List[str]:
    ignores = []
    ignore_file_path = os.path.join(src_path, './.clang-ignore')

    if os.path.exists(ignore_file_path):
        ignore_file = open(ignore_file_path, mode='r')

        for ignore in ignore_file.readlines():
            path = os.path.join(src_path, ignore.strip())
            glob_paths = list(filter(
                lambda f : os.path.exists(f),
                glob.glob(path, recursive=True),
            ))

            for glob_path in glob_paths:
                ignores.append(relative_to_abs_path(glob_path))

    return ignores

def get_files(src_path: str) -> List[str]:
    ignores = get_ignores(src_path)
    source_files = list(filter(
        lambda f : not (f in ignores),
        list(map(
            lambda f : os.path.abspath(f),
            glob.glob(os.path.join(src_path, './**/*.cc'), recursive=True),
        )
    )))
    header_files = list(filter(
        lambda f : not (f in ignores),
        list(map(
            lambda f : os.path.abspath(f),
            glob.glob(os.path.join(src_path, './**/*.h'), recursive=True),
        )
    )))

    return list(map(relative_to_abs_path, source_files + header_files))

def parse_args() -> argparse.Namespace:
    args_parser = argparse.ArgumentParser(description=__doc__)
    args_parser.add_argument(
        '-e',
        '--executable',
        action='store',
        default='clang-format',
        type=str,
    )
    args_parser.add_argument(
        '-q',
        '--quiet',
        action='store_true',
    )
    args_parser.add_argument(
        '-f',
        '--fix',
        action='store_true',
    )

    return args_parser.parse_args()

def get_red_print(print: str) -> str:
    return f'\x1b[31m{print}\x1b[0m'

def main() -> int:
    src_path = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '../src',
        )
    )
    args = parse_args()
    files = get_files(src_path)

    try:
        filename_problem_paths, filename_convention, lint_code = lint_files(
            src_path,
            args.executable,
            files,
            args.quiet,
            args.fix,
        )

        if len(filename_problem_paths) > 0:
            if not args.quiet:
                print(get_red_print(f'\nThe following files did not match the {filename_convention} format:'))
                print(
                    '\n'.join(list(map(
                        lambda s : f' {get_red_print("-")} {s}',
                        filename_problem_paths,
                    )))
                )
            return 1
    except Exception as error:
        print(error.args[0])
        return 1

    return lint_code

if __name__ == '__main__':
    sys.exit(main())
