## Project structure
### `scripts/`
Contains some useful Python scripts, described below this section.

### `build/`
Contains the compiled code. It is created when the `build` scripts is ran
successfully.

### `src/`
Contains the source code of the project.

### `src/app/`
Contains the main function and all the executables. It is possible to include
the public headers of the library from here.

### `src/lib/`
This is the directory where the application is stored as a library.

#### `src/lib/include/`
Contains the public headers of the library i.e. the
ones accessible from the application. The private headers are in the
`src/lib/src/` directory, next to their implementation.

#### `src/lib/src/`
Contains the implementation files of the library headers. The files
have to end in _.cc_ in order to be compiled.

#### `src/lib/external/`
Contains the dependencies of the application. They have to be targeted in
the `src/lib/CMakeLists.txt` file.

## Scripts
Run `run.py <SCRIPT>` or `python run.py <SCRIPT>` in the command line to run
one of the following scripts.
##### > [Python 3 is required to run the scripts.](https://www.python.org/downloads/)

### `lint`
Lints the source files with _Clang-Format_.

#### Flags
* `--executable` `-e`   - The Clang-Format executable.
* `--quiet` `-q`        - Disables logging the problems, but mantains the exit
                          code.
* `--fix` `-f`          - Enables the Clang-Format auto-formatter.
```
run.py lint
    [--executable | -e <EXECUTABLE>]
    [--quiet | -q]
    [--fix | -f]
```

### `build`
Builds the project in the `build/` directory and runs _Clang-Tidy_ to identify
the problems in the code.

> **Note that if the linter returns problems, the build directory is deleted**

> **Note that if the CMake generator does not output a compilation**
> **database then _clang-tidy_ cannot be executed and the flag `--no-lint`**
> **needs to be passed.**

#### Flags
* `--mode` `-m`         - The mode with which to build the project. The available are
                          _debug_ and _release_. The default one is _release_.
* `--executable` `-e`   - The CMake executable.
* `--generator` `-g`    - The CMake generator.
* `--lint-executable`   - The Clang-Tidy executable.
* `--fix` `-f`          - Enables the Clang-Tidy auto-formatter.
```
run.py build
    [--no-lint]
    [--mode | -m {debug, (release)}]
    [--generator | -g <GENERATOR>]
    [--executable | -e <EXECUTABLE>]
    [--lint-executable <EXECUTABLE>]
    [--fix | -f]
```
