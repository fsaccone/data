#include <app/helloworld.h>

Helloworld::Helloworld(int x) : x(x)
{}
