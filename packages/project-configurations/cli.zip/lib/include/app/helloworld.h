#pragma once

class Helloworld
{
    public:
        Helloworld(int x);
        int x;
};
