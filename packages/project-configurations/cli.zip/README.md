## Folder structure
### `app/`
This is the directory containing the main function. It is possible to include
the public headers of the library from here.

### `lib/`
This is the directory where the whole program is stored as a library.
> #### `lib/include/`
> This is the directory that contains the public headers of the library i.e. the
> ones accessible from the application. The private headers are in the
>`lib/src/` directory, next to their implementation.
>
> #### `lib/src/`
> This is the directory that contains the implementation files of all the
> library headers. The files have to end in `.cc` in order to be compiled.

## Scripts
### `build.py`
Builds the project in the `build/` directory. Pass `debug` as an argument
to build the project in debug mode. If there is no argument or the given
argument is invalid, the default mode is `release`. It is also possible to
specify the CMake generator via the `--generator` option.
```
./build.py [MODE] [--generator <GENERATOR_NAME>]
```
or
```
python build.py [MODE] [--generator <GENERATOR_NAME>]
```
