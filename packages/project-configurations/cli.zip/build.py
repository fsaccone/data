#!/usr/bin/env python3

import sys
import subprocess
import os
import shutil
from argparse import ArgumentParser

def main():
    cwd = os.getcwd()
    build_dir = os.path.join(cwd, 'build')
    config = 'Debug' if 'debug' in map(lambda a : str(a).lower(), sys.argv) else 'Release'
    flagsParser = ArgumentParser()
    flagsParser.add_argument('--generator', action='store')
    flags = flagsParser.parse_args()

    if os.path.exists(build_dir):
        shutil.rmtree(build_dir)

    os.makedirs(build_dir)

    subprocess.run(
        ['cmake', '..'] + (
            ['-G', flags.generator] if flags.generator else []
        ),
        cwd=build_dir, shell=True, check=True,
    )
    subprocess.run([
        'cmake',
        '--build', '.',
        '--config', config,
    ], cwd=build_dir, shell=True, check=True)

if __name__ == '__main__':
    try:
        main()
    except:
        pass
    finally:
        print('Press any key to exit...', end='')
        input()
