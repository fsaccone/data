import React from 'react'

export const App = (): JSX.Element => (
  <div></div>
)
