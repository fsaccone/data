#ifndef APP_APPLICATION_H_
#define APP_APPLICATION_H_

namespace App
{
    class Application
    {
        public:
            Application(int argc, char** argv);
            ~Application();

            void run();
    };
}

#endif
