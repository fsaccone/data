#include "application.h"

int main(int argc, char** argv)
{
    App::Application* app = new App::Application(argc, argv);
    app->run();
    delete app;

    return 0;
}
