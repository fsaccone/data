#ifndef APPLICATION_H_
#define APPLICATION_H_

namespace App
{
    class Application
    {
        public:
            Application(int argc, char** argv);
            ~Application();

            void run();
    };
}

#endif
