const config = {
  verbose: true,
  preset: 'ts-jest',
  testRegex: '.+\\.test\\.tsx?$',
}

module.exports = config
