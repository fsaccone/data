## Folder structure
### `app/src`
This is the directory containing the main function. It is possible to include
the public headers of the library from here.

### `app/lib/`
This is the directory where the whole program is stored as a library.

#### `app/lib/include/`
This is the directory that contains the public headers of the library i.e. the
ones accessible from the application. The private headers are in the
`app/lib/src/` directory, next to their implementation.

#### `app/lib/src/`
This is the directory that contains the implementation files of all the
library headers. The files have to end in _.cc_ in order to be compiled.

## Scripts
Run `run.py <SCRIPT>` or `python run.py <SCRIPT>` in the command line to run
one of the following scripts.
##### > [Python 3 is required to run the scripts.](https://www.python.org/downloads/)

### `lint`
Lints the source files with _Clang-Format_.

#### Flags
* `--executable` `-e`   - The Clang-Format executable.
* `--quiet` `-q`        - Disables logging the problems, but mantains the exit
                          code.
* `--fix` `-f`          - Enables the Clang-Format auto-formatter.
```
run.py lint
    [--executable | -e <EXECUTABLE>]
    [--quiet | -q]
    [--fix | -f]
```

### `build`
Builds the project in the `build/` directory and runs _Clang-Tidy_ to identify
the problems in the code.

> **Note that if the linter returns problems, the build directory is deleted**

> **Note that if the CMake generator does not output a compilation**
> **database then _clang-tidy_ cannot be executed and the flag `--no-lint`**
> **needs to be passed.**

#### Flags
* `--mode` `-m`         - The mode with which to build the project. The available are
                          _debug_ and _release_. The default one is _release_.
* `--executable` `-e`   - The CMake executable.
* `--generator` `-g`    - The CMake generator.
* `--lint-executable`   - The Clang-Tidy executable.
* `--fix` `-f`          - Enables the Clang-Tidy auto-formatter.
```
run.py build
    [--no-lint]
    [--mode | -m {debug, (release)}]
    [--generator | -g <GENERATOR>]
    [--executable | -e <EXECUTABLE>]
    [--lint-executable <EXECUTABLE>]
    [--fix | -f]
```
