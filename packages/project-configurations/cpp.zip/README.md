## Folder structure
### `app/`
This is the directory containing the main function. It is possible to include the
public headers in `/lib/` from here.

### `lib/`
This is the directory where the whole program is stored as a library.

> #### `lib/include/`
> This is the directory that contains the headers of the library. These can be
> public, if accessible from the application, or private, if they are used only
> inside the library. The **#include** directive root in both the library and the
> application is from the `public/` and `private/` folders.
>
> #### `lib/src/`
> This is the directory that contains the definition files of all the public and
> private headers.

#### `lib/external/`
This is the directory that contains all the dependencies of the library.

## Scripts
### `build.py`
Builds the project in the `build/` directory. Pass `debug`
to build the project in debug mode. If there is no argument or the given
argument is invalid, the default mode is `release`.
```
python build.py [MODE]
```
