#!/usr/bin/env python3

import sys
import subprocess
import os
import shutil
from glob import glob
from argparse import ArgumentParser

def lint(fix):
    if not shutil.which('clang-tidy'):
        return 'Unable to find `clang-tidy` executable.'

    cwd = os.getcwd()
    files = []

    for file in glob('app/**/*.cc', recursive=True):
        files.append(os.path.abspath(file).replace('\\', '/'))

    for file in glob('lib/include/**/*.h', recursive=True):
        files.append(os.path.abspath(file).replace('\\', '/'))

    for file in glob('lib/src/**/*.cc', recursive=True):
        files.append(os.path.abspath(file).replace('\\', '/'))

    for file in glob('lib/src/*.h', recursive=True):
        files.append(os.path.abspath(file).replace('\\', '/'))

    print('Linter problems:\n')

    for file in files:
        try:
            subprocess.run(
                [
                    'clang-tidy',
                    '--config-file=.clang-tidy',
                    '--format-style=file',
                    '--warnings-as-errors=*',
                    '--p', 'build',
                    file,
                ] + (['--fix-errors'] if fix else []),
                cwd=cwd,
                shell=True,
                check=True,
            )
        except subprocess.SubprocessError as err:
            print(err)

def run_cmake(generator):
    cwd = os.getcwd()
    build_dir = os.path.join(cwd, 'build')
    config = 'Debug' if 'debug' in map(lambda a : str(a).lower(), sys.argv) else 'Release'

    if os.path.exists(build_dir):
        shutil.rmtree(build_dir)

    os.makedirs(build_dir)

    subprocess.run(
        ['cmake', '..'] + (['-G', generator] if generator else []),
        cwd=build_dir,
        shell=True,
        check=True,
    )
    subprocess.run(
        [
            'cmake',
            '--build', '.',
            '--config', config,
        ],
        cwd=build_dir,
        shell=True,
        check=True,
    )

def build(generator):
    if not shutil.which('cmake'):
        return 'Unable to find `cmake` executable.'
    else:
        try:
            run_cmake(generator)
            print('\nThe project was built successfully.\n')
        except:
            sys.exit(1)

def main():
    flags_parser = ArgumentParser()
    flags_parser.add_argument('--generator', action='store')
    flags_parser.add_argument('--lint', action='store_true')
    flags_parser.add_argument('--lint-fix', action='store_true')
    flags = flags_parser.parse_args()

    build_error = build(flags.generator)

    if build_error:
        print(build_error)
        return 1

    continue_lint = 'y'

    if not flags.lint:
        continue_lint = input('Continue with linting the source code? ([Y]/N) ')

    if not continue_lint.lower().strip() == 'n':
        lint_error = lint(flags.lint_fix)

        if lint_error:
            print(lint_error)
            return 1

        input('Press ENTER to continue...')

    return 0

if __name__ == '__main__':
    sys.exit(main())
