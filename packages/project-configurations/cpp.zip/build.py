import sys
import subprocess
import os
import shutil

def main():
	cwd = os.getcwd()
	build_dir = os.path.join(cwd, 'build')
	config = 'Release'

	if 'debug' in map(lambda a : str(a).lower(), sys.argv):
		config = 'Debug'

	if os.path.exists(build_dir):
		shutil.rmtree(build_dir)

	os.makedirs(build_dir)

	subprocess.run(['cmake', '..'], cwd=build_dir, shell=True, check=True)
	subprocess.run(['cmake', '--build', '.', '--config', config], cwd=build_dir, shell=True, check=True)

if __name__ == '__main__':
	try:
		main()
	except:
		pass
