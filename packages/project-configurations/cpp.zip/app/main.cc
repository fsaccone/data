auto main(int argc, char** argv) -> int
{
    return 0;
}
