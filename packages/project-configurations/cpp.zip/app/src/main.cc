#include "app.h"

auto main(int argc, char** argv) -> int
{
    App::Main app;

    return 0;
}
