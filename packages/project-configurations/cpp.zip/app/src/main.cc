#include "vector.h"
#include <iostream>

auto
  main(int argc, char** argv) -> int
{
    Vector::Vector2 my_vec(2, 6);

    std::cout << my_vec.x;
    std::cout << my_vec.y;

    return 0;
}
