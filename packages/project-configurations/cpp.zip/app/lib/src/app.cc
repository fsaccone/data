#include "app.h"

namespace App
{
    Main::Main() = default;
}

