#include "application.h"

namespace App
{
    Application::Application(int argc, char** argv)
    {
    }

    Application::~Application()
    {
    }

    void Application::run()
    {
    }
}
