#include "vector.h"

namespace Vector
{
    Vector2::Vector2(int x, int y)
            : x(x),
              y(y)
    {
    }

    
}
