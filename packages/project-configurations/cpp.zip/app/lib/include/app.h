#ifndef APP_H_
#define APP_H_

namespace App
{
    class Main
    {
        public:
            Main();
            ~Main() = default;
    };
}

#endif

