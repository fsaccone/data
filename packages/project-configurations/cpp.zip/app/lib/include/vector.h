#ifndef VECTOR_H
#define VECTOR_H

#pragma once

namespace Vector
{
   class Vector2{
       public:
     int x;
       int y;

      Vector2(int, int);
        ~Vector2() = default;
    };
}

#endif
