#ifndef HELLOWORLD_H
#define HELLOWORLD_H

class Helloworld
{
    public:
        Helloworld();
};

#endif
