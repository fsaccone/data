#include <helloworld.h>

Helloworld::Helloworld() = default;
