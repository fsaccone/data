#!/usr/bin/env python3
"""
Runs one of the scripts.
Open `README.md` for more informations.
"""

import sys
import subprocess
import os
from typing import Dict, List, Tuple

SCRIPTS_DIR = os.path.abspath('./scripts')

def run_script(full_path: str, argv: List[str]) -> int:
    print(full_path)

    return subprocess.run(
        ['python', full_path, *argv],
        universal_newlines=True,
    ).returncode

"""
Returns a record of script-with-ext: script-full-path and a list of
script-no-ext
"""
def get_scripts() -> Tuple[Dict[str, str], List[str]]:
    scripts_names = os.listdir(SCRIPTS_DIR)
    scripts_fulldir = list(map(
        lambda f : os.path.join(SCRIPTS_DIR, f),
        scripts_names,
    ))
    scripts_names_no_ext = list(map(
        lambda n : n.split('.')[0],
        scripts_names,
    ))

    return (dict(zip(scripts_names, scripts_fulldir)), scripts_names_no_ext)

def main() -> int:
    code = 0
    scripts, script_names = get_scripts()
    chosen_script_fullpath = None
    script_argv_index = 2 if sys.argv[0] == 'python' else 1

    for name in script_names:
        if len(sys.argv) > script_argv_index:
            if sys.argv[script_argv_index].lower() == name.lower():
                chosen_script_fullpath = scripts[f'{name}.py']

    if not chosen_script_fullpath:
        if len(sys.argv) <= script_argv_index:
            print('Missing script. Run `./run.py <SCRIPT>` or `python run.py <SCRIPT>` instead.')
        else:
            print(f'Unknown script `{sys.argv[script_argv_index]}`')

        available_scripts = '\n'.join(list(map(
            lambda s : f' - {s}',
            script_names,
        )))

        print(f'The available scripts are:\n{available_scripts}')
        code = 1
    else:
        code = run_script(
            chosen_script_fullpath,
            sys.argv[2:] if (script_argv_index == 1) else sys.argv[3:],
        )

    input('\nPress ENTER to exit...')

    return code

if __name__ == '__main__':
    if sys.version_info[0] < 3:
        print('Python 3 or higher is required to run the script.')
        sys.exit(1)
    sys.exit(main())
