#!/usr/bin/env python3
"""
Lints, fixes and and builds the project in the `build/` directory.
Open `README.md` for more informations.
"""

import argparse
import glob
import os
import shutil
import subprocess
import sys
from typing import List, Tuple

def delete_dir(dir: str) -> None:
    if os.path.exists(dir) and os.path.isdir(dir):
        shutil.rmtree(dir)

def run_cmake(
    app_path: str,
    executable: str,
    mode: str,
    generator: str = None,
) -> Tuple[int, str]:
    """
    Returns (code, build_dir)
    """
    if not shutil.which(executable):
        raise Exception(f'Unable to find the `{executable}` executable.')

    code = 1
    build_dir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '../build',
        )
    )

    delete_dir(build_dir)
    os.mkdir(build_dir)

    make_command = [executable, app_path] + (
        ['-G', generator] if generator else []
    )
    build_command = [executable, '--build', '.', '--config', mode.capitalize()]
    for command in [make_command, build_command]:
        try:
            code = subprocess.run(
                command,
                cwd=build_dir,
                universal_newlines=True,
            ).returncode
        except OSError as error:
            raise Exception(f'An unexpected error occurred while running `{executable}`')

        if code != 0:
            break

    return (code, build_dir)

def lint_files(
    app_path: str,
    build_dir: str,
    executable: str,
    files: List[str],
    fix: bool,
) -> int:
    if not shutil.which(executable):
        raise Exception(f'Unable to find the `{executable}` executable.')

    print('\nLinter problems:\n')

    return_code = 1

    for file in files:
        command = [
            executable,
            file,
            '--config-file=.clang-tidy',
            '-p', build_dir,
        ] + (['--fix'] if fix else [])

        try:
            return_code = subprocess.run(
                command,
                cwd=app_path,
                universal_newlines=True,
            ).returncode
        except OSError as error:
            raise Exception(f'An unexpected error occurred while running `{executable}`')
        except:
            return_code = 1

        if return_code == 1:
            break

    return return_code

def is_in_argv(value: str) -> bool:
    return value.lower() in list(map(lambda a : a.lower(), sys.argv[1:]))

def relative_to_abs_path(path: str) -> str:
    return os.path.abspath(path)

def get_ignores(app_path: str) -> List[str]:
    ignores = []
    ignore_file_path = os.path.join(app_path, './.clang-ignore')

    if os.path.exists(ignore_file_path):
        ignore_file = open(ignore_file_path, mode='r')

        for ignore in ignore_file.readlines():
            path = f'./app/{ignore.strip()}'
            glob_paths = list(filter(
                lambda f : os.path.exists(f),
                glob.glob(path, recursive=True),
            ))

            for glob_path in glob_paths:
                ignores.append(relative_to_abs_path(glob_path))

    return ignores

def get_files(app_path: str) -> List[str]:
    ignores = get_ignores(app_path)
    source_files = list(filter(
        lambda f : not (f in ignores),
        list(map(
            lambda f : os.path.abspath(f),
            glob.glob(os.path.join(app_path, './**/*.cc'), recursive=True),
        )
    )))
    header_files = list(filter(
        lambda f : not (f in ignores),
        list(map(
            lambda f : os.path.abspath(f),
            glob.glob(os.path.join(app_path, './**/*.h'), recursive=True),
        )
    )))

    return list(map(relative_to_abs_path, source_files + header_files))

def parse_args() -> argparse.Namespace:
    args_parser = argparse.ArgumentParser(description=__doc__)
    args_parser.add_argument(
        '--no-lint',
        action='store_true',
    )
    args_parser.add_argument(
        '-m',
        '--mode',
        action='store',
        choices=['debug', 'release'],
        default='release',
        nargs=1,
    )
    args_parser.add_argument(
        '-g',
        '--generator',
        action='store',
        nargs=1,
    )
    args_parser.add_argument(
        '-e',
        '--executable',
        action='store',
        default='cmake',
        nargs=1,
    )
    args_parser.add_argument(
        '--lint-executable',
        action='store',
        default='clang-tidy',
        nargs=1,
    )
    args_parser.add_argument(
        '-f',
        '--fix',
        action='store_true',
    )

    return args_parser.parse_args()

def main() -> int:
    app_path = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),
            '../app',
        )
    )
    args = parse_args()
    files = get_files(app_path)
    build_dir = None
    build_code = 0
    lint_code = 0

    try:
        build_code, build_dir = run_cmake(
            app_path,
            args.executable,
            args.mode,
            args.generator
        )
    except Exception as error:
        delete_dir(build_dir)
        print(error.args[0])
        return 1

    if build_code != 0:
        delete_dir(build_dir)
        print('\nThe build did not succeed. The files were not linted.')
        return build_code

    if args.no_lint:
        print('\nThe `--no-lint` flag was passed. The files were not linted.')
        return build_code

    try:
        lint_code = lint_files(
            app_path,
            build_dir,
            args.lint_executable,
            files,
            args.fix,
        )
    except Exception as error:
        delete_dir(build_dir)
        print(error.args[0])
        return 1

    if lint_code != 0:
        delete_dir(build_dir)

    return lint_code

if __name__ == '__main__':
    sys.exit(main())
