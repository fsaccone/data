import {
  App,
} from 'app'
import 'index.css'
import React, {
  StrictMode,
} from 'react'
import {
  createRoot,
} from 'react-dom/client'

const div = document.createElement('div')
const root = createRoot(div)

root.render((
  <StrictMode>
    <App />
  </StrictMode>
))
document.body.append(div)
